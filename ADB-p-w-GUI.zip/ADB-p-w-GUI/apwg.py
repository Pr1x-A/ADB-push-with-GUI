import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import subprocess
import os

class AdbPushApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ADB Push GUI")
        self.root.geometry("550x350")
        self.root.configure(bg="white")

        self.file_path = ""
        self.phone_path = "/sdcard/Download/"

        # style
        style = ttk.Style(root)
        style.theme_use("clam")
        style.configure("TLabel", background="white", foreground="black", font=("Segoe UI", 10))
        style.configure("TButton", font=("Segoe UI", 9), padding=5)
        style.configure("TEntry", font=("Segoe UI", 10))

        # file select
        frame_file = ttk.Frame(root)
        frame_file.pack(fill="x", padx=10, pady=10)

        ttk.Label(frame_file, text="Selected file:").pack(side="left")
        self.file_label = ttk.Label(frame_file, text="(none)", foreground="gray")
        self.file_label.pack(side="left", padx=5)
        ttk.Button(frame_file, text="Browse...", command=self.choose_file).pack(side="right")

        ttk.Separator(root, orient="horizontal").pack(fill="x", padx=10, pady=5)

        # path select
        frame_path = ttk.Frame(root)
        frame_path.pack(fill="x", padx=10, pady=10)

        ttk.Label(frame_path, text="Phone path:").pack(side="left")
        self.path_entry = ttk.Entry(frame_path, width=40)
        self.path_entry.insert(0, self.phone_path)
        self.path_entry.pack(side="left", padx=5, fill="x", expand=True)
        ttk.Button(frame_path, text="Set", command=self.set_path).pack(side="right")

        ttk.Separator(root, orient="horizontal").pack(fill="x", padx=10, pady=5)

        # button
        frame_action = ttk.Frame(root)
        frame_action.pack(fill="x", padx=10, pady=10)
        ttk.Button(frame_action, text="Push file", command=self.push_file).pack(side="left")

        ttk.Separator(root, orient="horizontal").pack(fill="x", padx=10, pady=5)

        # log
        ttk.Label(root, text="ADB log:").pack(anchor="w", padx=10)
        self.log_text = tk.Text(
            root, height=10,
            bg="white", fg="black",
            insertbackground="black",
            relief="solid", borderwidth=1
        )
        self.log_text.pack(fill="both", expand=True, padx=10, pady=5)

    def choose_file(self):
        file_path = filedialog.askopenfilename(title="Select file")
        if file_path:
            self.file_path = file_path
            self.file_label.config(text=os.path.basename(file_path))

    def set_path(self):
        new_path = filedialog.askdirectory(title="Select local folder to simulate phone path")
        if new_path:
            self.path_entry.delete(0, tk.END)
            self.path_entry.insert(0, new_path)

    def push_file(self):
        self.phone_path = self.path_entry.get().strip()
        if not self.file_path:
            messagebox.showerror("Error", "Please select a file first.")
            return
        if not self.phone_path:
            messagebox.showerror("Error", "Please specify a phone path.")
            return

        try:
            result = subprocess.run(
                ["adb", "push", self.file_path, self.phone_path],
                capture_output=True,
                text=True
            )
            self.log_text.insert("end", result.stdout + "\n" + result.stderr + "\n")
            self.log_text.see("end")

            if result.returncode == 0:
                messagebox.showinfo("Success", f"File pushed to {self.phone_path}")
            else:
                messagebox.showerror("Error", "Failed to push file. See log for details.")
        except FileNotFoundError:
            messagebox.showerror("Error", "ADB not found. Make sure adb.exe is in PATH or next to this program.")

if __name__ == "__main__":
    root = tk.Tk()
    app = AdbPushApp(root)
    root.mainloop()
